package Palidrome;



public class ReversePalidrome7 {

	public static void main(String[] args) {
		String s ="radar";
		char[] ch=s.toCharArray();
		int i=0,j=ch.length-1;
		while(i<j) {
			if(ch[i]!=ch[j]) {
				System.out.println("Not peli");
				return;
			}
			i++;j--;
		}
		System.out.println("Pali");
		
	}

}
